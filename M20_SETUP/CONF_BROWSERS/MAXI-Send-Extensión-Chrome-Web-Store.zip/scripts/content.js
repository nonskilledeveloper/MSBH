
window.addEventListener("message", (event) => {

 if (event.source !== window || event.data.type !== "FROM_PAGE") {
  return;
}

  chrome.runtime.sendMessage({ type: "FROM_PAGE", payload: event.data }, (response) => { 
    if ( response && response.type === 'Success'){
      window.postMessage({ type: "FROM_PAGE_SUCCESS", payload: response }, "*") 
    }
  });
});

const habilitarWebCam = () => {
  chrome.runtime.sendMessage({ type: "WEBCAM", payload: "allow" }, (response) => { 
   
  });
}
const LimpiarStorage  = () =>{
  chrome.runtime.sendMessage({ type: "CLEANSTORAGE", payload: "all" }, (response) => { 
   
  });
}

habilitarWebCam();
//LimpiarStorage();

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function () {
    window.postMessage({ type: "FROM_PAGE", payload: "" }, "*");
  });
} else {
  window.postMessage({ type: "FROM_PAGE", payload: "" }, "*");
}
