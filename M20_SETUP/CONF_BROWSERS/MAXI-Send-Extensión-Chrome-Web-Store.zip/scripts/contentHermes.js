(function () {
  // Función reutilizable para aplicar autocomplete
  function aplicarAutocomplete() {
    let contador = 1;
    const elementos = document.querySelectorAll("input, select");

    elementos.forEach((el) => {
      // Solo aplicar a elementos visibles y relevantes
      if (
        el.matches("input[type='text'], [role='combobox'], .form-select, .dropdown-toggle")
      ) {
        if (contador === 1) {
          el.setAttribute("autocomplete", "off");
        } else {
          el.setAttribute("autocomplete", "new-password");
        }
        contador++;
      }
    });
  }

  // Aplica inmediatamente si el documento ya está cargado
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", aplicarAutocomplete);
  } else {
    aplicarAutocomplete();
  }

  // Observa cambios dinámicos en el DOM (como elementos agregados después)
  const observer = new MutationObserver(() => {
    aplicarAutocomplete();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });

  // Refuerzo adicional con setInterval por si alguna librería reemplaza los atributos
  setInterval(() => {
    aplicarAutocomplete();
  }, 3000); // cada 3 segundos
})();

