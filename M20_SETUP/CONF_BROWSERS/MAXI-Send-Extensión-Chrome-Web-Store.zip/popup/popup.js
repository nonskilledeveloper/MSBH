document.getElementById('run-program').addEventListener('click', async () => {
  document.getElementById('run-program').disabled = true;
  try {
    await chrome.runtime.sendMessage({ type: "FROM_POPUP" }, () => {
      document.getElementById('run-program').disabled = false;
    });
  } catch (error) {
    console.error("Error al comunicar con la app nativa:", error);
  }
});

class PopupManager {
  constructor() {
    this.initializeEventListeners();
  }

  initializeEventListeners() {
    document.querySelectorAll('.clean-btn').forEach(button => {
      button.addEventListener('click', (e) => this.handleCleanAction(e));
    });

    const cameraToggle = document.getElementById("cameraToggle");

    if (cameraToggle && chrome.contentSettings?.camera) {
      chrome.storage.local.get(["webcamPermission"], (data) => {
        const saved = data.webcamPermission ?? false;
        cameraToggle.checked = saved;

        if (saved) this.setWebcamPermission(true);
      });

      cameraToggle.addEventListener("change", () => {
        const enabled = cameraToggle.checked;
        chrome.storage.local.set({ webcamPermission: enabled });
        this.setWebcamPermission(enabled);
      });
    }
  }

  async handleCleanAction(e) {
    const button = e.currentTarget;
    const action = button.dataset.action;

    try {
      this.applyClickAnimation(button);
      await this.executeCleaningAction(action);

      const messages = {
        'autocomplete': '✅ Autocompletado desactivado / Autocomplete disabled!',
        'localstorage': '✅ Almacenamiento local limpiado / LocalStorage cleaned!'
      };

      const message = messages[action] || '✅ Operación completada / Operation completed!';
      this.showToast(message);
    } catch (error) {
      this.showToast('❌ Error: ' + error.message);
    } finally {
      this.removeClickAnimation(button);
    }
  }

  async executeCleaningAction(action) {
    const actionMap = {
      'autocomplete': () => this.handleAutocomplete(),
      'localstorage': () => this.handleLocalStorage()
    };

    const handler = actionMap[action];
    if (!handler) throw new Error('Acción desconocida / Unknown action');
    await handler();
  }

  async handleAutocomplete() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.reload(tab.id);
  }

  async handleLocalStorage() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab || !tab.url) return;

      const allowedHosts = [
        "hermes-hotfix.maxilabs.net",
        "hermes-dev.mylabs.mx",
        "sso.mylabs.mx"
      ];

      const url = new URL(tab.url);
      if (!allowedHosts.includes(url.hostname)) {
        this.showToast("⚠️ Solo permitido en sitios Hermes / Only allowed on Hermes sites");
        return;
      }

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          localStorage.clear();
          console.log("✅ localStorage limpiado / cleaned");
        }
      });

      this.showToast("✅ localStorage limpiado / cleaned");
    } catch (error) {
      throw new Error(`❌ Error borrando almacenamiento / Error clearing storage: ${error.message}`);
    }
  }

  async setWebcamPermission(enabled) {
    try {
      const patterns = [
        '*://*.mylabs.mx/*',
        '*://*.maxilabs.net/*',
        '*://*.maxiagentes.net/*'
      ];

      for (const pattern of patterns) {
        await chrome.contentSettings.camera.set({
          primaryPattern: pattern,
          setting: enabled ? 'allow' : 'ask'
        });
        await chrome.contentSettings.microphone.set({
          primaryPattern: pattern,
          setting: enabled ? 'allow' : 'ask'
        });
      }

      const msg = enabled
        ? "🎥 Permisos habilitados / Permissions enabled"
        : "🎥 Permisos revocados / Permissions revoked";
      this.showToast(msg);
    } catch (error) {
      throw new Error(`❌ Error configurando permisos / Setting permissions: ${error.message}`);
    }
  }

  applyClickAnimation(button) {
    button.style.transform = 'scale(0.95)';
  }

  removeClickAnimation(button) {
    button.style.transform = '';
  }

  showToast(message, duration = 3000) {
    const toast = document.getElementById('toast');
    toast.classList.add('hidden');
    void toast.offsetWidth;
    toast.textContent = message;
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, duration);
  }
}

document.addEventListener("DOMContentLoaded", () => new PopupManager());