
(function () {
  const originalGetUserMedia = navigator.mediaDevices.getUserMedia;

  chrome.storage.local.get(["webcamPermission"], (data) => {
    const permisoActivo = data.webcamPermission === true;

    if (!permisoActivo) {
      navigator.mediaDevices.getUserMedia = () => {
        console.warn("🚫 Acceso a la cámara bloqueado por la extensión.");
        return Promise.reject(new Error("Acceso a la cámara bloqueado por la extensión."));
      };
    } else {
      navigator.mediaDevices.getUserMedia = originalGetUserMedia;
    }
  });
})();
