chrome.runtime.onInstalled.addListener(() => {
  console.log("La extensión está instalada.");
});

chrome.runtime.onStartup.addListener(() => {
  console.log("El Navegador se ha abierto.");
  ClearLocalStorage();

  sendNativeMessage(
    { cmd_command: "start C:\\MaxiInstall\\Maxi\\HERMES2_agent.Installer\\Hermes2Agent.exe" },
    (response) => {
      console.log("Respuesta de la aplicación nativa:", response);
    }
  );
});

function sendNativeMessage(message, sendResponse) {
  try {
    const port = chrome.runtime.connectNative("com.maxi_send.hermes2");

    port.onMessage.addListener(function (msg) {
      console.log("Mensaje recibido del host nativo:", msg);
      if (sendResponse) {
        sendResponse({ message: "Conexión exitosa", type: "Success" });
      }
    });

    port.onDisconnect.addListener(function () {
      console.error("No se pudo conectar al host nativo.");
      if (sendResponse) {
        sendResponse({ message: "Error de conexión", type: "Disconnected" });
      }
    });

    setTimeout(() => {
      console.log("Enviando mensaje al host nativo:", message);
      port.postMessage(message);
    }, 500);
  } catch (error) {
    console.error("Error al comunicar con la app nativa:", error);
  }
}

function habilitarWebCam() {
  let cameraCurrentState = "";
  const patterns = [
    "https://*.mylabs.mx/*",
    "https://*.maxilabs.net/*",
    "https://*.maxiagentes.net/*"
  ];

  chrome.contentSettings.camera &&
    chrome.contentSettings.camera.get(
      { primaryUrl: "https://*.maxiagentes.net/*" },
      function (details) {
        cameraCurrentState = details.setting;
        if (cameraCurrentState !== "allow") {
          for (const pattern of patterns) {
            chrome.contentSettings.camera.set({
              primaryPattern: pattern,
              setting: "allow"
            });
            chrome.contentSettings.microphone.set({
              primaryPattern: pattern,
              setting: "allow"
            });
          }
        }
      }
    );
}

function ClearLocalStorage() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs.length === 0) return;
    const tab = tabs[0];
    const url = tab.url;

    const allowedHosts = [
      "hermes-dev.mylabs.mx",
      "sso.mylabs.mx",
      "hermes-hotfix.maxilabs.net"
    ];

    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname;

      if (!allowedHosts.includes(hostname)) {
        console.warn("🚫 Dominio no autorizado para limpiar localStorage:", hostname);
        return;
      }

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          console.log("✅ Limpiando localStorage en:", location.hostname);
          localStorage.clear();
        }
      });
    } catch (e) {
      console.error("❌ URL inválida:", url);
    }
  });
}

chrome.action.onClicked.addListener(() => {
  console.log("Se hizo clic en el icono de la extensión");
  sendNativeMessage({
    cmd_command: "start C:\\MaxiInstall\\Maxi\\HERMES2_agent.Installer\\Hermes2Agent.exe"
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Mensaje recibido en background:", message);
  try {
    if (message.type === 'WEBCAM') {
      habilitarWebCam();
    } else if (message.type === 'CLEANSTORAGE') {
      ClearLocalStorage();
    } else {
      sendNativeMessage({ cmd_command: "hostname" }, sendResponse);
      sendNativeMessage({
        cmd_command: "start C:\\MaxiInstall\\Maxi\\HERMES2_agent.Installer\\Hermes2Agent.exe"
      }, sendResponse);
    }
    return true;
  } catch (error) {
    console.error("Error al procesar mensaje en background:", error);
  }
});
